# Batas Evaluasi Tahap 7

- Dataset berjumlah 374 baris merupakan keluaran siap model Tahap 3; rincian asal dan kurasinya berada pada Tahap 2.
- Tiga puluh profil uji dibuat secara deterministik untuk evaluasi teknis; bukan data pasien atau peserta penelitian.
- Accuracy kategori literal dihitung dengan leave-one-out, voting uniform, k=1, dan jarak Manhattan.
- Label food_category merupakan metadata internal yang telah tersedia dan hanya dipakai untuk evaluasi, bukan fitur jarak.
- Accuracy relevansi rekomendasi yang diberi label pakar/peserta belum dapat dihitung karena label tersebut belum tersedia.
- Sat.Fat, Sugar, dan Sodium tidak tersedia sehingga tidak dievaluasi dan tidak diimputasi sebagai nol.
- Baseline sederhana memilih satu item per slot, sedangkan model terpadu T6 menyusun kombinasi multi-item; perbandingan bersifat diagnostik.
- Penilaian lapangan terhadap rekomendasi per pengguna memerlukan data partisipan dan instrumen penilaian terpisah.
