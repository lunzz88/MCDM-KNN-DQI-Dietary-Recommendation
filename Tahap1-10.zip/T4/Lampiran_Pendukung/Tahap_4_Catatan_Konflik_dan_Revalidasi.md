# Catatan Konflik Parameter Tahap 4

Konfigurasi aktif memakai angka eksplisit yang telah disetujui pada tabel numerik: warning ±10%, kritis ±25%, pelampauan limit +10%/+25%, dan natrium 2.300 mg.

Catatan naratif juga menyebut kelebihan kritis 50%, perlunya membedakan defisit dan kelebihan, serta natrium 2.000 mg. Catatan tersebut tidak mempunyai tabel angka pengganti yang ditandatangani. Karena itu, catatan dicatat sebagai pending revalidasi dan tidak diubah diam-diam menjadi parameter aktif.

Toleransi 15% pada formula skor target DQI dan kategori tampilan 80/65/50 adalah parameter operasional peneliti, bukan angka yang diklaim telah divalidasi pakar.
