# Status Target Proposal Tahap 5

- Target accuracy proposal: **> 85%**.
- Accuracy literal klasifikasi kategori (KNN k=1, manhattan, LOO): **97.86%**.
- Status batas 85% pada diagnostik kategori: **TERCAPAI**.
- Status target accuracy kategori literal: **TERCAPAI SECARA LITERAL**.
- Hit@1: **97.86%**, hanya metrik retrieval; tidak digunakan sebagai pengganti accuracy.

Accuracy literal di atas memakai metadata `food_category` internal sebagai label evaluasi dan voting kategori deterministik dari tetangga. Nilai ini belum sama dengan accuracy rekomendasi menurut pakar/pengguna. Accuracy rekomendasi nyata baru dapat dihitung setelah tersedia label relevan/tidak relevan dari penilaian pakar atau pengguna pada keluaran rekomendasi.
